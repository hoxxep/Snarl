# Snarl

Growl style notifications for your web app.


## Documentation

Snarl is using Jekyll to generate the documentation site.

For now, check the (currently unfinished) site at [hoxxep.github.io/Snarl](https://hoxxep.github.io/Snarl) for usage docs.


## License
Snarl is maintained by [Liam Gray](http://hoxxep.github.io), and released under the [MIT license](https://github.com/hoxxep/Snarl/blob/master/LICENSE). 

Copyright &copy; 2014 Liam Gray. All rights reserved.